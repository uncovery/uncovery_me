<?php

function umc_frontpage() {
    $out = '';
    
    $user = umc_is_online();
    if ($user['online'] == false) {
        $status = 'offline';
    } else {
        $username = $user['username'];
        $email = $user['email'];
        $level = $user['groups'][0];
        $status = $level;
    }
    $out .= "<div>";
    switch ($status) {
        // if not logged in / not whitelisted
        case "offline": 
            $out .= "Welcome! If you are already a member here, please <a href=\"http://uncovery.me/wp-admin/profile.php\">login</a> to see your control panel!"
                . "If you are not a member yet, please goto <a href=\"http://uncovery.me/whitelist/\">this page</a> to become one!";

            break;
        case "Guest":
            $out .= "Welcome, $username!"
                . "Since you are a Guest, you might want to take get <a href=\"http://uncovery.me/private-area-allocation-map/\">building rights</a>?";
            break;
        default:
            $out .= "Welcome back, $username!";
            // user data
    }
    $out .= "</div>";

    // recent posts & comments 
    $out .= "<div style=\"font-size:smaller; border:1px solid grey; float:right; padding:10px; width:47%;\"><h1>Recent Posts & Comments</h1>"; 
    $out .= "<ul>";
    $args = array('numberposts' => 5, 'offset'=> 0);
    $myposts = get_posts($args);
    foreach ($myposts as $post) {
        $post_id = $post->ID;
        $out .= "<li><a href=\"".  get_permalink($post_id) . "\">" .  $post->post_title . "</a></li>";
        // recent comment
        $out .= "<ul>";
        $comment_args = array('status'=>'approve', 'number'=>'10', 'post_id'=>$post_id);
        $mycomments = get_comments($comment_args);
        foreach ($mycomments as $comment) {
            $out .= "<li><a href=\"".  get_comment_link($comment->id) . "\">" .  umc_trim_title($comment->comment_content)
                . "</a> by ". $comment->comment_author . "</li>";
        }
        $out .= "</ul>";
    }
    $out .= "</ul></div>";
    
    // forum posts

    $out .= "<div style=\"font-size:smaller; border:1px solid grey; float:right;  padding:10px; width:47%;\"><h1>Recent Forum posts</h1>";
    $out .= "<ul>";
    $sql = "SELECT user_login, wp_posts.id as post_id, post_author, post_title, post_type "
        . "FROM wp_posts LEFT JOIN wp_users ON post_author=wp_users.id "
        . "WHERE (post_type='topic' OR post_type='reply') AND post_status='publish' "
        . "ORDER BY post_modified DESC LIMIT 15;";
    $rst = mysql_query($sql);
    while ($row = mysql_fetch_array($rst, MYSQL_ASSOC)) {
        $post_id = $row['post_id'];
        $out .= "<li>". $row['user_login'] .' <a class="bbp-reply-topic-title" href="' . esc_url( bbp_get_reply_url($post_id) ) 
            . '" title="' . bbp_get_reply_excerpt($post_id, 50 ) . '">' . bbp_get_reply_topic_title($post_id) . '</a></li>';
        // recent comment
        $out .= "<ul>";
        $comment_args = array('status'=>'approve', 'number'=>'10', 'post_id'=>$post_id);
        $mycomments = get_comments($comment_args);
        $out .= "</ul>";
    }

    $out .= "</ul></div><div style=\"clear:both\"></div>";
    

    $out .= "<div><h1>Your lots</h1>";
    $lots = umc_user_getlots($username);
    foreach ($lots as $lot) {
        $out .= "<span style=\"float:left;\">{$lot['lot']} ({$lot['world']})<br>{$lot['image']}</span>";
    }
    $out .= "</div><div style=\"clear:both\"></div>";

    // recent forum posts
    
    // contests
    $out .= "<hr>Current running contests:"
        . umc_new_listcontests().  "<hr>";


    echo $out;
}

function umc_trim_title($title) {
    $limit = "40";
    $pad="...";

    if(strlen($title) > $limit) {
        $title = substr($title, 0, $limit) . $pad;
    }
    return $title;
}

?>