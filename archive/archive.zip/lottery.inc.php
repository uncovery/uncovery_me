<?php
//
//global $UMC_SETTING, $WS_INIT;
//
//$WS_INIT['lottery'] = array(  // the name of the plugin
//    'default' => array( // this is the default help
//        'help' => array(
//            'title' => 'Lottery',  // Enter in the Uncovery Grand lottery!!
//            'short' => 'Buy Lottery Tickets for Uncs and win prizes!',  // a short description
//            'long' => "You can buy one ticket for 50 uns.", // a long add-on to the short description
//            ),
//    ),
//    'status' => array(
//        'help' => array(
//            'short' => 'Shows the status of the lottery',
//            'long' => "You can enter an ID to show the status of a specific lottery, otherwise the latest is shown.",
//            'args' => '[ID]',
//        ),
//        'function' => 'umc_lottery_status',
//    ),
//    'buy' => array(
//        'help' => array(
//            'short' => 'Buys Lottery tickets',
//            'long' => "Enter an amount of tickets that you want to buy. You can only buy for the current active lottery.",
//            'args' => '<amount>',
//        ),
//        'function' => 'umc_lottery_buy',
//    ),
//    'new' => array(
//        'help' => array(
//            'short' => 'Starts a new lottery',
//            'long' => "Will start a new lottery round. If there is another lottery already running, it will close the last one",
//        ),
//        'function' => 'umc_lottery_buy',
//        'security' => array(
//            'groups' => array('Owner'),
//         ),
//    ),
//);
//
//function umc_lottery_buy() {
//    global $WSEND;
//    $tickets_price = 50;
//    $player = $WSEND['player'];
//    $args = $WSEND['args'];
//
//    if (isset($args[2])) {
//        settype($balance, 'float');
//        $amount = $args[2];
//        settype($amount, 'int');
//        $tickets = floor($amount * $tickets_price);
//    } else {
//        umc_error("{red}You need to specify the amount of tickets. See {yellow}/shophelp lottery");
//    }
//
//    $sql = "SELECT minecraft_iconomy.balance FROM iConomy WHERE username = '$player';";
//    $rst = mysql_query($sql);
//    $num_rows = mysql_num_rows($rst);
//    if ($num_rows == 0) {
//        umc_error("{red}Internal Error: Please notify uncovery.;");
//    } else {
//        $row = mysql_fetch_array($rst, MYSQL_ASSOC);
//        $balance = $row['balance'];
//    }
//
//    if ($tickets < 1 || $amount < 1) {
//        umc_error("{red}You need to buy at least 1 Lottery Ticket. For $amount Uncs you get only $amount tickets (ratio is $ticket_ratio!");
//    } else if ($amount > $balance) {
//        umc_error("{red}Sorry, you do not have that much money.");
//    } else {
//        $newamount = $tickets / $tickets_price;
//        // umc_ws_cmd("money take $player $newamount", 'asConsole');
//          
//        if ($amount !== $newamount) {
//            umc_echo("{gold}Cannot buy " . ($amount * $tickets_price) .  " tickets. Spent amount has been reduced to $newamount Uncs.");
//        }
//        umc_announce("{gold}$player{gray} just bought {purple}$newamount{cyan} Lottery tickets!{gray}!");
//    }
//    // we need to have a new table that stores the tickets that users bought and insert the bought tickets here.
//    // if the user already bought tickets, they have to be added in the same line.
//}
//
//function umc_lottery_status() {
//
//    
//    
//}
//
//
//function umc_lottery_new() {
//
//    
//    
//}

?>