<?php
/*
function umc_blog_cleanup() {
    global $UMC_SETTING;
    require_once(ABSPATH . WPINC . '/registration.php');
    
    // wp_delete_user

    // read userlist from world directory
    $w = array();
    $messages = array(
	'old_account' => "Dear %s,\n\n \n",
    
    
    );
    // read whitelist
    $whitelist = umc_read_data('whitelist');
    $whitelist = $whitelist['whitelist'];
    
    // read banned players
    $banned_players = umc_read_data('banned_players');
    $banned_players = $banned_players['banned_players'];
    
    // read permissions
    $permissions = umc_read_data('permissions');
    $permissions = $permissions['permissions']['users'];
    $new_permissions = $permissions;
    
    // go through permissions, search names in userfiles, fix capitalization
    $folder = $UMC_SETTING['world_folder'] . "players/";
    foreach ($permissions as $username => $data) {
	// now iterate folder
	if ($handle = opendir($folder)) {
	    while (false !== ($file = readdir($handle))) {
		if (substr($file,-4) == '.dat') {
		    $file_user = substr($file,0,-4);
		    if ((strcasecmp($file_user, $username) == 0) && ($file_user != $username)) {
			unset($new_permissions[$username]);
			$new_permissions[$file_user] = $data;
			echo "$file_user = $username ".count($new_permissions) ." \n";
			continue;
		    } 
		}
	    }
	}
    }
    var_dump($permissions);
    var_dump($new_permissions);
    
    // check if all whitelist users have a user account
    $arr = array();
    foreach ($whitelist as $username => $user) {
	if ($uname_check = username_exists($username)) { // username is in blog
	    //ok
	} else {
	    $banned = false;
	    if (array_key_exists($username, $banned_players)) {
		$banned = true;
	    }
	    // find users that are on whitelist but not even in the blog
	    $w['whitelist_wo_blog'][$username] = array('user' => $username, 'banned' => $banned, 'removed' => true);
	    // remove from whitelist 
	    unset($whitelist[$username]);
	}
    }
    $whitelist = array('whitelist' => $whitelist);
    umc_write_data('whitelist', $whitelist);
    
    $folder = $UMC_SETTING['world_folder'] . "players/";
    if ($handle = opendir($folder)) {
	while (false !== ($file = readdir($handle))) {
	    if (substr($file,-4) == '.dat') {
		$username =  substr($file,0,-4);
		$filename = $folder . $file;
		$filetime = filemtime($filename);
		$age_ts = mktime() - $filetime;
		$age = time_difference($age_ts);
		// let's check if the username is in the blog
		require_once(ABSPATH . WPINC . '/registration.php');
		$banned = false;
		$removed = false;
		if (array_key_exists($username, $banned_players)) {
		    $banned = true;
		    // delete banned users
		    unlink($filename);
		    $removed = true;
		}		
		if ($uname_check = username_exists($username)) { // usernam is in blog
		    if (array_key_exists($username, $permissions)) { // user has building rights
                $w['userfile_with_bldng_rights'][$username] =  array('user' => $username, 'banned' => $banned, 'removed' => $removed, 'last_login' => $filetime);
		    } else {
                $w['userfile_wo_bldng_rights'][$username] =  array('user' => $username, 'banned' => $banned, 'removed' => $removed, 'last_login' => $filetime);
		    }
		    if ($age['months'] >= 1) { // did not login for a long time (1 month plus)
                $w['one_month_no_login'][$username] = array('user' => $username, 'banned' => $banned, 'removed' => $removed, 'last_login' => $filetime);
		    }
		} else { // userfile exists but no blog registration
		    $w['has_userfile_no_account'][$username] = array('user' => $username, 'banned' => $banned, 'removed' => $removed, 'last_login' => $filetime);
		}
	    }
	}
	closedir($handle);
    }
    //var_dump($w);
    //var_dump($permissions);
}
*/

