<?php
/*
include_once($UMC_PATH_MC . '/server/bin/index.php');

global $Settler_questions;
$Settler_questions = array(
    0 => array('text'=>'How will you get to your lot?', 'true'=>1,
            'answers'=>array('0'=>'I use /warp <lotname> to get there', '1'=>'I walk there', '2'=>'I beg the admin to teleport me there')),
    1 => array('text'=>'How do you know on which lot you are?', 'true'=>2,
            'answers'=>array('0'=>'There is a sign on each lot', '1'=>'I cannot know', '2'=>'I use a wooden sword')),
    2 => array('text'=>'What can you do if you do not like your lot?', 'true'=>1,
            'answers'=>array('0'=>'I change to a different one', '1'=>'I cannot do anything', '2'=>'I beg the admin to change it')),
    3 => array('text'=>'Which color is the thin line around the unoccupied lots on the 2D map?', 'true'=>1,
            'answers'=>array('0'=>'Red', '1'=>'White', '2'=>'Black')),
    4 => array('text'=>'How do you get a wooden sword?', 'true'=>1,
            'answers'=>array('0'=>'Don\'t need one, got a Diamond Sword', '1'=>'There is a kit for it', '2'=>'I beg the admin')),
    5 => array('text'=>'How big is a protected lot in the empire?', 'true'=>0,
            'answers'=>array('0'=>'128x128 blocks', '1'=>'200x200 blocks', '2'=>'50x50 blocks')),
    6 => array('text'=>'If you want to get to A1 in the empire, where do you walk from spawn?', 'true'=>2,
            'answers'=>array('0'=>'North-East', '1'=>'North-West', '2'=>'South-West')),
    7 => array('text'=>'What does the area P31 in the empire world look like?', 'true'=>0,
            'answers'=>array('0'=>'Water', '1'=>'Mountains', '2'=>'Snow', '3'=>'Desert')),
    8 => array('text'=>'How do you know where West is?', 'true'=>0,
            'answers'=>array('0'=>'Where the clouds & sun go', '1'=>'I do not care', '2'=>'I ask someone')),
    9 => array('text'=>'What do you need to do to become Architect?', 'true'=>1,
            'answers'=>array('0'=>'I beg an Admin', '1'=>'I build cool stuff and hope it happens', '2'=>'I take the exam.')),
    10=> array('text'=>'What is a sure way to get banned?', 'true'=>0,
            'answers'=>array('0'=>'Xray, fast-click & hacked clients', '1'=>'Minimaps', '2'=>'Optifine')),
);

function umc_return_result() {
    global $Settler_questions;
    $user = umc_is_online();
    if ($user['online'] == false) {
        return $user['message'];
    } else {
        $username = $user['username'];
        $email = $user['email'];
    }

    $result = $_POST['result'];

    if (isset($_POST['q'])) {
        $world = $_POST['world'];
        if ($world == 'flatlands') {
            $data_type = 'regions_flatlands';
            $lot_prefix = 'flat_';
        } else if ($world == 'empire'){
            $data_type = 'regions_empire';
            $lot_prefix = 'emp_';
            // check for reserved lot for 1.7.2:
        } else {
            echo "<h2>You need to choose the world for your lot!!</h2>"
                . "<br>Please click the back-button on your browser and amke sure you filled the form in step number 5!";
            return false;
        }

        echo "Checking Questions...";
        // check the questions
        $q = $_POST['q'];
        $area = $q['0']['0'].$q['0']['1'] ;
        $lot = strtolower("$lot_prefix$area");
        foreach ($Settler_questions as $q_index => $item) {
            if ($_POST[$q_index] != $item['true']) {
                return "<h2>You answered some or all of the questions wrong! </h2>Please click the back-button on your browser and try again!";
            }
        }
        echo "All questions answered correctly!<br>";

        // assign the lot
        $result = umc_assign_lotOwner($user, $world, $lot);
        if (!$result) {
            echo "You failed the application. Please press the back-button on your browser and try again";
            return;
        }

        // send email to admin
        $headers = 'From:' . $email . "\r\n" .
            'Reply-To:' . $email . "\r\n" .
            'X-Mailer: PHP/' . phpversion();
        $subject = "[Uncovery Minecraft] Area Protection $world";
        $mailtext = "The user: $username (email: $email) registered the lot $lot in World $world.\n\n";
        mail('minecraft@uncovery.me', $subject, $mailtext, $headers);
    } else {

        echo "You failed the application";
    }
}

function umc_give_protected_lot() {
    // user has to be logged in
    global $Settler_questions;

    $user = umc_is_online();
    if ($user['online'] == false) {
        return $user['message'];
    } else {
        $username = $user['username'];
        $email = $user['email'];
    }

    // user submitted form, process it
    $out = '<div style="float: left; background: url(\'http://uncovery.me/wp-content/uploads/2012/04/sprites-1.png\') '
        . 'no-repeat -128px 0px; width: 32px; height: 32px; margin-right: 8px;"></div><strong style="font-size: 120%;">Step 6: Pick a survival or creative (flat) world.</strong>'
        . "<form action=\"http://uncovery.me/application-result/#result\" method=\"post\">\n"
        . "<input type=\"radio\" name=\"world\" value=\"empire\">Empire World (Survival, normal landscapes)<br>"
        . "<input type=\"radio\" name=\"world\" value=\"flatlands\">Flatlands World (Creative, flat)<br><br>"
    //which field do you want?
        . '<div style="float: left; background: url(\'http://uncovery.me/wp-content/uploads/2012/04/sprites-1.png\') '
        . 'no-repeat -128px 0px; width: 32px; height: 32px; margin-right: 8px;"></div><strong style="font-size: 120%;">Step 7: Pick the lot that you want.</strong>'
        . "<p><strong>Please choose the coordinates:</strong><select name=\"q[0][0]\"></p>\n";
    
    $out_number = $out_letter = '';
    for ($i=1; $i<=32; $i++) {
        $out_number.="<option value=\"$i\">$i</option>\n";
        $j = chr(64 + $i);
        if ($i > 26) {
            $j = "A". chr(38 + $i);
        }
        $out_letter.="<option value=\"$j\">$j</option>\n";
    }
        $out .="$out_letter</select><select name=\"q[0][1]\">$out_number</select>\n\n";
        $out .= '<div style="float: left; background: url(\'http://uncovery.me/wp-content/uploads/2012/04/sprites-1.png\') '
        . 'no-repeat -128px 0px; width: 32px; height: 32px; margin-right: 8px;"></div><strong style="font-size: 120%;">Step 8: Answer these questions</strong>'
        . '<p>You need to fill out this questionnaire. This is here to make sure that you read the instructions. So, don’t come and ask in-game how to find your lot. '
        . 'Do not ask what the answers to the questions are. Once you fill it out correctly, you will get a confirmation on the bottom of the page. '
        . 'You will be instantly Settler and receive access to your lot.</p>';

    foreach ($Settler_questions as $q_index => $item) {
        $question = $item['text'];
        $answers = $item['answers'];
        $out .= "<p>$question<ul style=\"list-style-type:none; padding:0px;\">\n";
        foreach ($answers as $a_index => $text){
            $out .= "<li style=\"margin:0px;padding:0px;\"><input type=\"radio\" name=\"$q_index\" value=\"$a_index\" /> $text</li>\n";
        }
        $out .= "</ul></p>\n";
    }
    $out .= "<p class=\"submit\"><input type=\"submit\" name=\"wp-submit\" id=\"wp-submit\" class=\"button-primary\" "
        . "value=\"Apply\" tabindex=\"100\" /></p><br /></form>\n\n";
    echo $out;

}

function umc_give_skylands_lot($world = 'aether') {

    // user has to be logged in
    $user = umc_is_online();
    if ($user['online'] == false) {
        return $user['message'];
    } else {
        $username = $user['username'];
        $email = $user['email'];
    }

    $group = $user['groups'][0];

    if (isset($_GET['world'])) {
        $world = $_GET['world'];
    }
    if ($world == 'aether') {
        $prefix = 'aet_';
        $max = 16;
    } else if ($world == 'kingdom') {
        $world = 'kingdom';
        $prefix = 'king_';
        $max = 16;
    } else {
        $world = 'skyblock';
        $prefix = 'block_';
        $max = 20;
    }

    if (isset($_POST['q'])) {
        $q = $_POST['q'];
        $area = $q['0']['0'].$q['0']['1'] ;
        $lot = strtolower($prefix. $area);
        if ($world == 'kingdom') {
            $sublot = $q['0']['2'];
            if ($sublot !== "N") {
               $lot = strtolower($prefix. $area. "_" . $sublot);
            }
        }
        
        // assign the lot
        $result = umc_assign_lotOwner($user, $world, $lot);
        if (!$result) {
            echo "You failed the application. Please press the back-button on your browser and try again";
            return;
        }

        // send email to admin
        $subject = "[Uncovery Minecraft] Area Protection $world";
        $headers = "From: $email" . "\r\n" .
            "Reply-To: $email" . "\r\n" .
            'X-Mailer: PHP/' . phpversion();
        $mailtext = "The user: $username (email: $email) reserved lot $lot in $world.\n\n";
        mail('minecraft@uncovery.me', $subject, $mailtext, $headers);
    } else {
        $out = "<form action=\"#result\" method=\"post\">\n"
            //which field do you want?
            . "<h2 class=\"protect_question\">Which field do you want?</h2>\n"
            . "<strong>Please choose the coordinates:</strong><select name=\"q[0][0]\">\n";

        $out_number = $out_letter = '';
        for ($i=1; $i<=$max; $i++) {
            $out_number.="<option value=\"$i\">$i</option>\n";
            $j = chr(64 + $i);
            if ($i > 26) {
                $j = "A". chr(38 + $i);
            }
            $out_letter.="<option value=\"$j\">$j</option>\n";
        }

        $out .="$out_letter</select><select name=\"q[0][1]\">$out_number</select>\n\n";
        if ($world =='kingdom') {
            $out .= "<select name=\"q[0][2]\"><option value=\"N\">Normal Lot (256x256 blocks, 10'000 Uncs)</option>"
                . "<option value=\"A\">Vertical Street lot \"A\" (16x256 blocks, 650 Uncs)</option>"
                . "<option value=\"B\">Corner Lot \"B\" (16x16 blocks, 40 Uncs)</option>"
                . "<option value=\"C\">Horizontal Street lot \"C\" (256x16 blocks, 650 Uncs)</option></select>";
        }
        $out .= "<p class=\"submit\"><input type=\"submit\" name=\"wp-submit\" id=\"wp-submit\" class=\"button-primary\" "
            . "value=\"Apply\" tabindex=\"100\" /></p><br /></form>\n\n";
        echo $out;
    }
}


function umc_assign_lotOwner($user, $world, $lot) {
    global $UMC_SETTINGS;
    $user = umc_is_online();
    $username = $user['username'];
    echo '<a name="result"></a>';
    // user has to have logged into the server
    echo "Trying to buy lot $lot in world $world for user $user<br>";
    echo "Checking when you logged in last... ";
    $old_users = umc_old_users();
    $tmp = strtolower($username);
    
    if (!isset($old_users[$tmp])) {
        echo "<h1>It seems you never logged into the minecraft server. Please log in & out of the server once.  Then you can reserve a lot</h1>";
        return false;
    }
    echo "{$old_users[$tmp]['lastlogin']}<br>";

    echo "Checking that the lot $lot exists in world $world.... ";
    // check if region exists at all
    if (!umc_check_lot_exists($world, $lot)) {
        echo "<h1>Lot $lot could not be found in $world!!</h1>";
        return false;
    }
    echo "OK<br>";

    // check if the lot if still free
    echo "<br>Checking if the lot is still free... ";
    $lot_Owners = umc_region_check_Owners($world, $lot);
    if (count($lot_Owners) > 0) {
        if (in_array(strtolower($username), $lot_Owners)) {
            echo "<h1>You own the lot $lot already!</h1>";
            return false;
        } else {
            echo "<h1>The lot was already given away to someone else! Please choose a different lot.</h1>";
            return false;
        }
    }

    $reserved = umc_get_move_targets();
    if (in_array(strtolower($lot), $reserved)) {
        echo "<h2>This lot has been reserved, please take one with a WHITE border on the map!</h2>";
        return false;
    }
    echo "OK<BR>";
    
    echo "Checking that you still have available lots in world $world....<br>";
    // check if the user still has available lots
    $user_lots = umc_check_lot_number($user, $world);
    if ($user_lots['avail_lots'] < 1) {
        echo "<h1>You do not have any available lots</h1>";
        return false;
    }
    $logtext_kingdom = '';
    if ($world == 'kingdom') {  
        // check the number of main lots the user has
        $main_lots = 0;
        foreach ($user_lots['lot_list'] as $userlot) {
            $lot_arr = explode ("_", $userlot);
            if (!isset($lot_arr[2])) {
                $main_lots++;
            }
        }
        // pay money
        $lot_arr = explode ("_", $lot);
        if (isset($lot_arr[2]) && $main_lots < 2) {
            echo "<br><strong>You need to own 2 Normal lots in the kingdom before you can buy corner or street lots!<strong><br>";
            return false;
        } else if (isset($lot_arr[2]) && $lot_arr[2]=='b') {
            $value = 40; // B 39
        } else if ($lot_arr[2]=='c' || $lot_arr[2]=='a') {
            $value = 650; // A, C 630
        } else {
            $value = 10000;  // normal 10000
        }
        echo "Checking if you have enough money to buy the lot... ";
        // check the money
        $sql = "SELECT * FROM minecraft_iconomy.mineconomy_accounts WHERE account = '$tmp';";
        $rst = mysql_query($sql);
        $count = mysql_num_rows($rst);
        if ($count !== 1) {
            echo "<br>Could not find your Uncs Account!<br>";
            return false;
        } 
        $row = mysql_fetch_array($rst, MYSQL_ASSOC);
        if ($row['balance'] < $value) {
            echo "You do not have enough money in your account! You need $value, but have only {$row['balance']}!<br>";
            return false;
        }
        echo "Yes! {$row['balance']} Uncs<br>";
        $new_balance = $row['balance'] - $value;
        $sql = "UPDATE minecraft_iconomy.mineconomy_accounts SET balance=$new_balance WHERE account='$tmp';";
        $rst = mysql_query($sql);
        echo "<strong>Your account was debited by $value Uncs. You have $new_balance Uncs left in your account</strong><br>";
        $logtext_kingdom = " Accounting: $tmp had {$row['balance']}, bought $lot for $value, ended up with $new_balance";
    } else if ($world == 'skyblock') { 
        $value = 5000;
         echo "Checking if you have enough money to buy the lot... ";
        // check the money
        $sql = "SELECT * FROM minecraft_iconomy.mineconomy_accounts WHERE account = '$tmp';";
        $rst = mysql_query($sql);
        $count = mysql_num_rows($rst);
        if ($count !== 1) {
            echo "<br>Could not find your Uncs Account!<br>";
            return false;
        } 
        $row = mysql_fetch_array($rst, MYSQL_ASSOC);
        if ($row['balance'] < $value) {
            echo "You do not have enough money in youyr account! You need $value, but have only {$row['balance']}!<br>";
            return false;
        }
        echo "Yes! {$row['balance']} Uncs<br>";
        $new_balance = $row['balance'] - $value;
        $sql = "UPDATE minecraft_iconomy.mineconomy_accounts SET balance=$new_balance WHERE account='$tmp';";
        $rst = mysql_query($sql);
        echo "<strong>Your account was debited by $value Uncs. You have $new_balance Uncs left in your account</strong><br>";
        $logtext_kingdom = " Accounting: $tmp had {$row['balance']}, bought $lot for $value, ended up with $new_balance";       
    }

    // promote the user to Settler
    $usergroup = umc_get_userlevel($username);
    if ($usergroup == 'Guest' || $usergroup == '') {
        echo "Promoting you to Settler Status...OK<Br>";
        umc_exec_command("pex promote $username");
        echo "Reloading permissions...OK<br>";
        umc_exec_command('pex reload');
    }

    // add user to lot chosen
    echo "Adding you to the lot $lot in $world....OK<br>";
    umc_region_add_player(strtolower($username), $world, $lot, 1);
    
    // logfile entry
    $logtext = "[GIVE] ". date("Y-m-d H:i:s") ." lot $lot in world $world to $username$logtext_kingdom\n";
    $logfile = $UMC_PATH_MC. "/server/logs/lot_give.log";
    file_put_contents($logfile, $logtext, FILE_APPEND);

    // reload lots & permissions
    echo "Reloading Regions...OK<br><h1>Congratz! you are now the proud Owner of $lot in $world!";
    umc_exec_command("regions load -w $world");
    umc_exec_command("ch qm u Congrats $username for claiming lot $lot!");
    return true;
}
 
 

function umc_region_create_player($player) {
    $sql = "INSERT INTO minecraft_worldguard.user (name) VALUES ('$player');";
    $rst = mysql_query($sql);
    return mysql_insert_id();
}
   */




?>