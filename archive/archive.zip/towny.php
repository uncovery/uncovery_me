<?php

function umc_towny() {

    $types = array('nations', 'towns', 'residents');
    // create menu
    $out = '';
    foreach ($types as $type) {
        $str_type = ucfirst($type);
        $out .= "<a href=\"?type=$type\">$str_type</a> | ";
    }

    if (isset($_GET['item'])) {
        $item = filter_input(INPUT_GET, 'item', FILTER_SANITIZE_STRING);
        
    }
    if (isset($_GET['type'])) {
        $get_type = $_GET['type'];
        if (in_array($get_type, $types)) {
            $type = $get_type; 
        } else {
            return "error";
        }
        $item = filter_input(INPUT_GET, 'item', FILTER_SANITIZE_STRING);
        if ($item == null) {
            $out .= umc_list_towny_files($type);
        } else {
            $out .= umc_display_towny_file($type, $item);
        }
    } else {
        $out .= umc_list_towny_files($types[0]);
    }

    return $out;
}

function umc_list_towny_files($type) {
    global $UMC_PATH_MC;
    $path = $UMC_PATH_MC. '/server/bukkit/plugins/Towny/data/' . $type;
    $out = '<ul>';
    $files = scandir($path);
    foreach ($files as $file) {
        if (substr($file,-4) == '.txt') {
            $item_name = explode(".", $file);
            // check resident for town membership
            $content = umc_read_towny_file($path . "/" . $file);
            if (($type == 'residents') && !isset($content['town'])) {
            
            } else {
                $out .= "<li><a href=\"?type=$type&amp;item={$item_name[0]}\">{$item_name[0]}</a></li>";
            }
        }
    }
    $out .= '</ul>';
    return $out;
    echo 'listing '. $type; 
}

function umc_display_towny_file($type, $item) {
    global $UMC_PATH_MC;
    $path = $UMC_PATH_MC. '/server/bukkit/plugins/Towny/data/' . $type . "/$item.txt";
    $out = "<h2>$item</h2><ul>";
    $items = umc_read_towny_file($path);
    foreach ($items as $item => $value) {
        $out .= umc_format_towny_line($type, $item, $value);
    }
    $out .= '</ul>';
    return $out;
}

function umc_format_towny_line($group, $type, $value) {
    $group_details = array(
        'nations' => array(
            'towns' => 'towns',
            'friends' => 'nations',
            'assistants' => 'residents',
            'capital' => 'towns',
        ),
        'towns' => array (
            'residents' => 'residents',
            'mayor' => 'residents',
            'nation' => 'nations',
            'assistants' => 'residents',
        ),
        'residents' => array (
            'town' => 'towns',
            'friends' => 'residents',
        ),
    );
    $type_details = $group_details[$group];
    $ignore_list = array('lastOnline', 'registered', 'isNPC');

    $type_str = ucfirst($type);
    if (in_array($type, $ignore_list)) {
        return;
    } else if (array_key_exists($type, $type_details)) {
        $value = umc_list_values($value, $type_details[$type]);
    } else {
        $value = umc_list_values($value, $type);
    }
    return "<li><strong>$type_str:</strong> $value</li>";
}

function umc_list_values($data, $type) {
    $out = '';
    if (!strstr($data, ',')) {
        $out = umc_format_value($data, $type);
    } else {
        $values = explode(',', $data);
        foreach ($values as $value) {
            if (strlen($value) > 0) {
                $out .= umc_format_value($value, $type);
                $out .= ", ";
            }
        }       
    }
    return $out;
}

function umc_format_value($value, $type) {
    $out = '';
    switch ($type) {
        case 'towns':
        case 'residents':
        case 'nations':
            $out .= "<a href=\"?type=$type&amp;item=$value\">$value</a>";
            break;
        case 'lastOnline':
            $out .= date("Y-m-d G:i:s", $value);
            break;
        default:
            $out .= $value; // . $type;
    }
    return $out;
}

function umc_read_towny_file($path) {
    $ignore = array();
    $file = file($path);
    $item = array();
    foreach ($file as $line) {
        $line = trim($line);
        $element = explode("=", $line);
        if (strlen($element[1]) > 0) {
            $item[$element[0]] = $element[1];
        }
    }
    //var_dump($item);
    return $item;
}
?>