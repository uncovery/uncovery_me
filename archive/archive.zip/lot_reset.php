<?php 


// does the standard process to find out which lots are to be reset and then rests them accordingly
function umc_reset_all_lots($world = false) {
/*
Usage: copychunk [src] [dest] [x1] [y1] [x2] [y2]
       copychunk [src] [dest] [x1] [y1] [x2] [y2] [dx1] [dy1] [dx2] [dy2]

   [src] and [dest] are both paths to minecraft world directories
   [x1] [y1] [x2] [y2] are chunk coords (not block coords) of a square region
   [dx1] [dy1] [dx2] [dy2] are OPTIONAL chunk coords for destination. If not
                           given, src and destination coords are the same.
*/

    global $UMC_SETTING, $UMC_PATH_MC;
    echo "Reset lots world $world\n";
    $longterm = $UMC_SETTING['longterm'];

    if (!$world) {
        die();
    }

    $rights = umc_region_data($world);
    $old_users = umc_old_users();
    $banned_users = umc_read_data('banned_players');
    $banned_users = $banned_users["banned_players"];

    $del_lots = array();
    $logtext = '';
   
    $date_now = umc_datetime();
    $now = $date_now->format("Y-m-d H:i:s");
    
    foreach ($rights as $lot => $opt) {
        if ((count($opt['owners']['players']) > 0) && (substr($lot, 0, 3) !== 'con' )) {
            $owner = $opt['owners']['players'][0];
            $all_owners = $opt['owners']['players'];
            $ownergroup = umc_get_userlevel($owner);
            if (in_array($owner, $banned_users)) {
                $del_lots[$lot] = $opt;
                $logtext .= "[RESET] $now lot $lot in world $world of $owner (Banned!)\n";
            } else if (in_array('_abandoned_', $all_owners)) {
                $logtext .= "[RESET] $now lot $lot in world $world of $owner (manual reset with user _abandoned_)\n";
                $del_lots[$lot] = $opt;
            } else if (isset($old_users[$owner])) {
                if ($old_users[$owner]['months'] > 1 && in_array($ownergroup, $longterm)) {
                    $del_lots[$lot] = $opt; // special users after 2 months
                    $logtext .= "[RESET] $now lot $lot in world $world of $owner (advanced user after 2 month)\n";
                } else if ($old_users[$owner]['months'] > 1 && ($world == 'skylands') && !in_array($ownergroup, $longterm)) {
                    $del_lots[$lot] = $opt; // skylands lots after 2 months
                    $logtext .= "[RESET] $now lot $lot in world $world of $owner (skylands lot after 2 month)\n";
                } else if ($old_users[$owner]['months'] > 1 && ($world == 'aether') && !in_array($ownergroup, $longterm)) {
                    $del_lots[$lot] = $opt; // skylands lots after 2 months
                    $logtext .= "[RESET] $now lot $lot in world $world of $owner (skylands lot after 2 month)\n";
                } else if ($old_users[$owner]['months'] > 0 && !in_array($ownergroup, $longterm)) {
                    $del_lots[$lot] = $opt; // everyone else after 1 months
                    $logtext .= "[RESET] $now lot $lot in world $world of $owner (normal user after 1 month)\n";
                }
            }
        }
        if ($world == 'skyblock' && isset($del_lots[$lot])) {
            // remove user inventory
            foreach ($opt['owners']['players'] as $player) {
                $inv = $UMC_PATH_MC . '/server/bukkit/plugins/Multiverse-Inventories/worlds/skyblock/' . $player . '.yml';
                if (file_exists($$inv)) {
                    unlink($inv);
                    $logtext .= "[DELETE INV] $now $inv of $player after skyblock reset\n";
                }
            }
        }
    }
    // all lots remove users and reset the lot
    foreach ($del_lots as $lot => $opt) {
        $del_lots[$lot]['reset_users'] = true;
        $del_lots[$lot]['reset_lot'] = true;
    }

    //
    echo "fixing " . count($del_lots) . " expired in world $world\n";
    foreach ($del_lots as $lot => $opt) {
        umc_do_reset_lot($lot, $world, $opt);
    }
    
    $logfile = $UMC_PATH_MC . "/server/logs/lot_give.log";
    echo $logtext;
    file_put_contents($logfile, $logtext, FILE_APPEND);
    echo "done\n";
}

//  Add a player to a region.  Works for Owners (default) as well as members.
function umc_region_add_player($player, $world, $lot, $owner=1) {
    $world_id = umc_get_worldguard_id('world',$world);
    $user_id = umc_get_worldguard_id('user',$player);
    if (!$user_id) {
        $sql = "INSERT INTO minecraft_worldguard.user (name) VALUES ('$player');";
        $rst = mysql_query($sql);
        $user_id = mysql_insert_id();
        echo "Created User $user, ID $user_id<br>";
    }
    if ($world_id === null || $user_id === null || !umc_check_lot_exists($world_id,$lot)) {
        return false;
    }
   
    //-- Let's add!
    $sql = "INSERT INTO minecraft_worldguard.region_players (region_id,world_id,user_id,Owner) ".
           "VALUES ('$lot',$world_id,$user_id,$owner)";
    $rst = mysql_query($sql);
    return true;
}
// Remove all members/Owners and all flags from a region
// part of the standard lot reset process
function umc_region_remove_all($world = '', $lot = '', $in_game = true) {
    $world_id = umc_get_worldguard_id('world', $world);
    if ($world_id === null || !umc_check_lot_exists($world_id, $lot)) {
        // echo "World $world or lot $lot could not be found!;";
        return false;
    }

    //  Remove all players
    $sql = "DELETE FROM minecraft_worldguard.region_players WHERE region_id = '$lot' AND world_id = $world_id";
    $rst = mysql_query($sql);
    if ($in_game) {
        // echo "Deleted players from lot $lot in World $world;";
    }

    $sql = "DELETE FROM minecraft_worldguard.region_flag WHERE region_id = '$lot' AND world_id = $world_id";
    $rst = mysql_query($sql);
    if ($in_game) {
        // echo "Deleted flags from lot $lot in World $world;";
        umc_ws_cmd("region load -w $world", 'asConsole');
    }
    // fix version
    $sql = "UPDATE minecraft_srvr.lot_version SET choice=NULL, `version`=`mint_version` WHERE lot='$lot' LIMIT 1;";
    mysql_query($sql);
    return true;
}

// this function resets lots per standard daily reset process
// it needs the coordinates as options together with switches if only the lot, only the users or both are reset
function umc_do_reset_lot($lot, $world, $opt) {
    global $UMC_PATH_MC;
    $exec_path = $UMC_PATH_MC. '/server/chunk/copychunk';
    $good_map = $UMC_PATH_MC. "/server/worlds/mint/$world";
    $bad_map = $UMC_PATH_MC. "/home/minecraft/server/bukkit/$world";

    if ($opt['reset_lot']) {
        $min_x = floor($opt['min']['x'] / 16);
        $max_x = floor($opt['max']['x'] / 16);
        $min_z = floor($opt['min']['z'] / 16);
        $max_z = floor($opt['max']['z'] / 16);
        //echo "$min_x $min_z $max_x $max_z";

        // echo "Doing $lot\n";

        // check if craftbukkit is running
        $exec_cmd = 'ps ax | grep -v grep | grep -v -i SCREEN | grep craftbukkit.jar';
        exec($exec_cmd, $output);

        // reset lots
        $output = array();
        if (count($output) > 0 ) {
            die("Minecraft is running!");
        }
        $exec_cmd = "$exec_path $good_map $bad_map $min_x $min_z $max_x $max_z";
        //echo $exec_cmd . "\n";
        exec($exec_cmd, $output);
        $output = array();
    }

    if ($opt['reset_users']) {
        // remove Owner & flags
        echo "Resting users from $lot\n";
        umc_region_remove_all($world, $lot, false);
    }
}

// this function is for manual lot resets along an array
// only executed on demand, does not check if minecraft is running.
function umc_reset_back() {
    die();
    global $UMC_PATH_MC;
    $lots = array('emp_w11','emp_v11','emp_v10','emp_u10','emp_y15','emp_x15','emp_w25','emp_q17','emp_n9','emp_o11','emp_ae2','emp_g29','emp_w20','emp_w21','emp_x21','emp_s14','emp_t13','emp_t14',
        'emp_u13','emp_ab1','emp_ab2','emp_p13','emp_u26','emp_y22','emp_aa21','emp_v30','emp_n16','emp_x16','emp_u27','emp_u30','emp_v27','emp_n26','emp_t8','emp_t9','emp_u8','emp_u9','emp_v31',
        'emp_s16','emp_c16','emp_r16','emp_u7','emp_f12','emp_v5','emp_w4','emp_ae1','emp_l22','emp_z26','emp_ac1','emp_ac2','emp_ad1','emp_i30','emp_k13','emp_l13','emp_u23','emp_w28','emp_k22',
        'emp_f16','emp_a27','emp_z20','emp_y18','emp_y19','emp_g17','emp_w17','emp_ab30','emp_k15','emp_l15','emp_l16','emp_w18','emp_o13','emp_v8','emp_v9','emp_t20','emp_ac4','emp_c24','emp_x3',
        'emp_ad32','emp_w29','emp_k11','emp_k12','emp_l12','emp_d26','emp_n15','emp_e19','emp_g20','emp_x17','emp_g1','emp_c4','emp_j1','emp_j15','emp_m19','emp_ad2','emp_c9','emp_m16','emp_u11',
        'emp_u12','emp_ab13','emp_y11','emp_y12','emp_z11','emp_z12','emp_h19','emp_ac14','emp_ac16','emp_b27','emp_d27','emp_e27','emp_d29','emp_d28','emp_e28','emp_e29','emp_y20','emp_s29','emp_h3',
        'emp_h4','emp_ab15','emp_o18','emp_f2','emp_ac10','emp_f1','emp_ab16','emp_l17','emp_x27','emp_x28');
    $world = 'empire';
    $exec_path = $UMC_PATH_MC . '/server/chunk/copychunk';
    $good_map = "/disk2/mirror/home/minecraft/server/worlds/save/empire";
    $bad_map = $UMC_PATH_MC . "/server/bukkit/$world";

    $world = 'empire';
    $rights = umc_region_data($world);

    foreach ($lots as $lot) {
        $opt = $rights[$lot];
        $min_x = floor($opt['min']['x'] / 16);
        $max_x = floor($opt['max']['x'] / 16);
        $min_z = floor($opt['min']['z'] / 16);
        $max_z = floor($opt['max']['z'] / 16);
        //echo "$min_x $min_z $max_x $max_z";

        $exec_cmd = "$exec_path $good_map $bad_map $min_x $min_z $max_x $max_z";
        echo $exec_cmd . "\n";
        exec($exec_cmd, $output);
        $output = array();
    }
}

?>