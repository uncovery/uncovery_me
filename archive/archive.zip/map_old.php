<?php
// make one single map out of the file-based maps
function umc_assemble_tmc_map($world = 'empire') {
    global $UMC_SETTING, $UMC_PATH_MC;
    $chunks = array('empire' => 10);
    $folder = $UMC_PATH_MC . "/server/maps/$world";
    $final_target = $UMC_PATH_MC . '/server/maps/';
    // tile.0.4.png

    // iterate directory for assembly
    $files = scandir($folder . "/png");
    $matrix = array();
    $dim_y = $dim_x = 0;
    $bad = array('.', '..', 'tiles.html');
    foreach ($files as $filename) {
        $pathinfo = pathinfo($filename);
        $file_arr = explode(".", $filename);
        // only convert files that are in the dimension limits of the map
        if ($pathinfo['extension'] == 'png' && umc_detect_minmax($world, $file_arr[1], $file_arr[2], "$folder/png")) {
            $command = "convert $folder/png/$filename -quality 60% $folder/jpg/{$pathinfo['filename']}.jpg";
            //echo $command . "\n";
            exec($command);
            // create matrix
            $x_coord = $file_arr[1];
            $y_coord = $file_arr[2];
            $matrix[$y_coord][$x_coord] = $pathinfo['filename'] . ".jpg";
            $dim_y = max(count($matrix[$y_coord]), $dim_y);
            $dim_x = max(count($matrix), $dim_x);
            ksort($matrix[$y_coord]);
            ksort($matrix);
        }
    }

    $file_list = '';
    foreach ($matrix as $ycoord => $yrow) {
        // $filelist = '';
        foreach ($yrow as $xcoord => $file) {
            $filelist .= " $folder/jpg/" . $file;
        }
    }

    // exec("cd $folder");
    $file_1 = $final_target . $world . '_large.jpg';
    $command = 'montage '. $filelist . " -background none -mode Concatenate -tile {$dim_x}x{$dim_y} $file_1";
    //echo $command . "\n";
    exec($command);
    $file_2 = $final_target . $world . '.jpg';
    $size = $UMC_SETTING['map_img_'. $world]['max_coord'] * 2;
    $border = $UMC_SETTING['map_img_'. $world]['chunkborder'];
    $command = "convert -crop {$size}x{$size}+{$border}+{$border}\! $file_1 $file_2";
    exec($command);
    // echo $command . "\n";
}


// used only needed files for the single-file maps
function umc_detect_minmax($world, $chunk1, $chunk2, $path) {
    // create lots
    $maxmin = array(
        'empire' => array('min_1' => -5, 'min_2' => -5, 'max_1' => 4, 'max_2' => 4),
        'flatlands' => array('min_1' => -3, 'min_2' => -3, 'max_1' => 2, 'max_2' => 2),
        'aether' => array('min_1' => -4, 'min_2' => -4, 'max_1' => 3, 'max_2' => 3),
        'kingdom' => array('min_1' => -5, 'min_2' => -5, 'max_1' => 4, 'max_2' => 4),
        'skyblock' => array('min_1' => -3, 'min_2' => -3, 'max_1' => 2, 'max_2' => 2),
        'empire_new' => array('min_1' => -5, 'min_2' => -5, 'max_1' => 4, 'max_2' => 4),
        'city' => array('min_1' => -2, 'min_2' => -4, 'max_1' => 3, 'max_2' => 1),
        'darklands' => array('min_1' => -5, 'min_2' => -5, 'max_1' => 5, 'max_2' => 5),
    );
    $data = $maxmin[$world];
    if (($chunk1 <= $data['max_1'] && $chunk1 >= $data['min_1']) && ($chunk2 <= $data['max_2'] && $chunk2 >= $data['min_2'])) {
        return true;
    } else {
        return false; //die("There was an illegal map file found: $path\n");
    }


    // This code generates the above table.

    $worlds = array('empire' => 128, 'flatlands' => 128, 'aether' => 192, 'kingdom' => 272, 'skyblock' => 128, 'empire_new' => 128, 'city' => 0);
    foreach ($worlds as $world => $dim) {
        // make chunk files
        // clean up data files
        $folder = $UMC_PATH_MC . "/server/bukkit/$world/region";
        if ($world == 'empire_new') {
            $folder = $UMC_PATH_MC . "/server/bukkit_172/empire/region";
        }
        $files = scandir($folder);
        $max_1 = $max_2 = $min_1 = $min_2 = 0;
        foreach ($files as $filename) {
            $file_arr = explode(".", $filename);
            $max_1 = max(intval($file_arr[1]), $max_1);
            $min_1 = min(intval($file_arr[1]), $min_1);
            $max_2 = max(intval($file_arr[2]), $max_2);
            $min_2 = min(intval($file_arr[2]), $min_2);
        }
        echo "'$world' = array('min_1' => $min_1, 'min_2' => $min_2, 'max_1' => $max_1, 'max_2' => $max_2); \n";
    }
}

// Old code, displays file-sized maps instead of single-file maps.
// process did not work for heatmaps.
function umc_display_chunk_images($world = 'empire') {
    global $UMC_SETTING;

    $folder = $UMC_PATH_MC. "/server/maps/$world/jpg";

    $map = $UMC_SETTING["map_img_$world"];
    if ($world == 'empire_new') {
        $map = $UMC_SETTING["map_img_empire"];

    }

    $files = scandir($folder);
    $matrix = array();
    $bad = array('.', '..', 'tiles.html');
    $out = '';
    foreach ($files as $filename) {
        if (in_array($filename, $bad)) {
            continue;
        }
        // $file_arr = array();
        $file_arr = explode(".", $filename);
        // create matrix
        $x_coord = $file_arr[2] * 512;
        $z_coord = $file_arr[1] * 512;
        $x1 = conv_x($x_coord, $map);
        $z1 = conv_z($z_coord, $map);
        $out .= "<img class=\"map_image\" src=\"http://uncovery.me/map/$world/jpg/$filename\" style=\"position:absolute; top:{$x1}px; left:{$z1}px;\">\n";
    }
    return $out;
}

?>