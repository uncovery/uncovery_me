<?php

/* 
this is to check if an empty lot has been chosen already
    - by a higher user or 
    - by a same level user on an earlier date.
*/
function umc_validate_newlot($lot, $username, $choices) {
    $ranks = array('Guest' => 0,
        'Settler' => 1,'SettlerDonator' => 2,'SettlerDonatorPlus' => 3,
        'Citizen' => 4,'CitizenDonator' => 5,'CitizenDonatorPlus' => 6,
        'Architect' => 7,'ArchitectDonator' => 8,'ArchitectDonatorPlus' => 9,
        'Designer' => 10 ,'DesignerDonator' => 11,'DesignerDonatorPlus' => 12,
        'Master' => 13,'MasterDonator' => 14,'MasterDonatorPlus' => 15,
        'Elder' => 16,'ElderDonator' => 17,'ElderDonatorPlus' => 18,
        'Owner' => 19);

    $incoming_lvl = umc_get_userlevel($username);
    $incoming_rank = $rank[$incoming_lvl];
    // get user's choice date for a lot otherwise take current
    // iterate choices once to find if the current user chose already
    $incoming_date = false;
    foreach ($choices as $old_lot => $data) {
        if ($data['username']==$username) {
            $incoming_date = $data['timestamp'];
        }
    }

    // iterate all lots that have been picked by other users
    foreach ($choices as $old_lot => $data) {
        // the lot by current user has been picked by other user
        if ($data['choice'] == $lot) {
            $existing_claimer = $data['username'];
            $existing_lvl = umc_get_userlevel($existing_claimer);
            // check but always prevent the users current choice from being kicked out of the list with $existing_claimer != $username
            if (($ranks[$existing_claimer] <= $ranks[$existing_lvl]) && ($existing_claimer != $username)) {
                // the incoming user is a lower rank than an existing choice, fail lot
                return false;
            } else if (($incoming_date) && ($ranks[$existing_claimer] == $incoming_rank) && ($existing_claimer != $username)) {
                // the incoming user picked this lot once already, we check if the other choice was earlier
                $incoming_time = strtotime($incoming_date);
                $existing_time = strtotime($data['timestamp']);
                if ($existing_time < $incoming_time) {
                    return false;
                }
            }
        }
    }
    // this lot has never been picked by other users, so include it in the list of available lots
    return true;
}


// Bump anyone who has chosen $lot and make their selection 'keep'
// Email them to inform them they must make another choice
// Then perform this function again for anyone who claimed the original lot
// if the bump is justified HAS to be checkeb outside this function. 
// Only the recursive is always valid since KEEP always overrides MOVE
function umc_bump_claimant($lot) {
    // first, we iterate all lots that have been picked by someone and see if the incoming lot has been picked
    $existing_claimer = false;
    // var_dump($choices);
    
    $choices = umc_get_lot_choices();
    foreach ($choices as $old_lot => $data) {
        if ($data['choice'] == $lot) {
            $original_lot = $old_lot;
            // do we have someone who picked that lot before? He will be bumped
            $existing_claimer = $data['username'];
        }
    }

    // 
    if ($existing_claimer) {
        // Send email to existing_claimer
        $headers = 'From:minecraft@uncovery.me' . "\r\nReply-To:minecraft@uncovery.me\r\n" . 'X-Mailer: PHP/' . phpversion();
        $subject = "[Uncovery Minecraft] NOTICE: One of your previous empire lot selections has been overridden.";
        $content = "Dear $existing_claimer, \r\n\r\n"
        . "As we stated in a previous email, when we give out new lots and two users want the same lot, we prioritize by rank, and within rank by date.\r\n\r\n"
        . "Your previous selection to move to {$lot} from {$original_lot} has been overridden by a higher-ranking user.\r\n"
        . "Your choice for {$original_lot} has been reverted to 'Keep', so this lot will remain untouched if you take no further action.\r\n"
        . "You may, if you wish, make a different selection by returning to the following page: \r\n"
        . "http://uncovery.me/1-7-2-lot-movereset-requests/\r\n\r\n"
        . "Sorry for the inconvenience.\r\n"
        . "Thanks!\r\n"
        . "Uncovery\r\n"
        . "-- \r\nUncovery Minecraft Admin\r\n";
        // need to find out user email here
        $email = umc_user_email($existing_claimer);
        mail($email, $subject, $content, $headers);
        // send email to admin
        $subject = "[Uncovery Minecraft] BUMP NOTICE: User $existing_claimer has been bumped off $lot";
        $content = "The user $existing_claimer ($email) has been bumped out of lot choice $lot and moved back to keep original lot $original_lot!";
        mail('minecraft@uncovery.me', $subject, $content, $headers);
  
        // Do the bump
        $sql = "UPDATE minecraft_srvr.lot_choice SET choice = 'keep' WHERE username = '{$existing_claimer}' AND choice = '{$lot}';";
        $rst = mysql_query($sql);

        // Call self recursively, in case anyone had selected $original_lot, which is now set to 'keep'
        umc_bump_claimant($original_lot);
    } else {
        // There was no claim for this lot, we are done.
    }
}


?>
